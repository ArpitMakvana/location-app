export const environment = {
  production: true,
  baseUrl:'https://dx.ezybilling.in/api/staff'
};
